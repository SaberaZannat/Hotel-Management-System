
package demoppp;

abstract class Room {

    // Unique room number
    private String roomNumber;

    // Price per night in USD
    private double pricePerNight;

    // Availability status of the room
    private boolean isAvailable;

    // Maximum number of guests allowed
    private int capacity;

    // Constructor
    public Room(String roomNumber, double pricePerNight, int capacity) {
        this.roomNumber = roomNumber;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.isAvailable = true;
    }

    // Abstract methods
    public abstract String getRoomType();

    public abstract String getRoomDetails();

    // Getter and Setter methods
    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        if (pricePerNight < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }
        this.pricePerNight = pricePerNight;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive");
        }
        this.capacity = capacity;
    }

    // Price calculation methods
    public double calculateTotalPrice(int nights) {
        if (nights <= 0) {
            throw new IllegalArgumentException("Number of nights must be positive");
        }
        return pricePerNight * nights;
    }

    public double calculateTotalPrice(int nights, double discount) {
        if (discount < 0 || discount > 100) {
            throw new IllegalArgumentException("Discount must be between 0 and 100");
        }
        double price = calculateTotalPrice(nights);
        return price * (1 - discount / 100);
    }

    // To String method
    @Override
    public String toString() {
        return String.format(
            "Room %s | Type: %-8s | Capacity: %d | Price: $%.2f/night | Available: %s",
            roomNumber, getRoomType(), capacity, pricePerNight,
            isAvailable ? "Yes" : "No"
        );
    }
}
