
package demoppp;

// ============================================================
// CUSTOMER CLASS
// ============================================================

class Customer extends Person {

    // Customer's email address
    private String email;

    // Customer's phone number
    private String phone;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    /*
     * Creates a Customer object with personal and contact details.
     *
     * @param id      Unique customer identifier
     * @param name    Customer's full name
     * @param email   Customer's email address
     * @param phone   Customer's phone number
     */
    public Customer(String id, String name, String email, String phone) {
        // Call parent constructor (Person)
        super(id, name);
        this.email = email;
        this.phone = phone;
    }

    // ============================================================
    // GETTER & SETTER METHODS
    // ============================================================

    // Returns customer email
    public String getEmail() {
        return email;
    }

    // Updates customer email
    public void setEmail(String email) {
        this.email = email;
    }

    // Returns customer phone number
    public String getPhone() {
        return phone;
    }

    // Updates customer phone number
    public void setPhone(String phone) {
        this.phone = phone;
    }

    // ============================================================
    // TO STRING METHOD
    // ============================================================

    /*
     * Returns a concise formatted string containing
     * customer information.
     */
    @Override
    public String toString() {
        return String.format("Customer: %s (ID: %s) | Email: %s | Phone: %s",
                getName(), getId(), email, phone);
    }

    // ============================================================
    // CUSTOMER DETAILS METHOD
    // ============================================================

    /*
     * Returns a detailed, multi-line string of customer information,
     * suitable for printing or display in reports.
     */
    public String getCustomerDetails() {
        return String.format("CUSTOMER DETAILS\n" +
                        "• Name: %s\n" +
                        "• Customer ID: %s\n" +
                        "• Email: %s\n" +
                        "• Phone: %s",
                getName(), getId(), email, phone);
    }
}
