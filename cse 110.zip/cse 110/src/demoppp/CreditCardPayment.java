
package demoppp;

// ============================================================
// CREDIT CARD PAYMENT CLASS
// ============================================================

class CreditCardPayment implements PaymentProcessor {

    // Card number of the credit card
    private String cardNumber;

    // Card holder name
    private String cardHolder;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    /*
     * Creates a CreditCardPayment object with card details.
     *
     * @param cardNumber  Full credit card number
     * @param cardHolder  Name of the card holder
     */
    public CreditCardPayment(String cardNumber, String cardHolder) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }

    // ============================================================
    // INTERFACE METHODS
    // ============================================================

    /*
     * Processes a payment for the given booking ID and amount.
     * Displays transaction info and simulates processing.
     *
     * @param bookingId  Booking ID to process payment for
     * @param amount     Payment amount
     * @return           true if payment successful
     * @throws PaymentException if payment is declined
     */
    @Override
    public boolean processPayment(String bookingId, double amount) throws PaymentException {
        System.out.println("\nProcessing Credit Card Payment...");
        System.out.printf("Booking: %s\n", bookingId);
        System.out.printf("Amount: $%.2f\n", amount);
        System.out.printf("Card Holder: %s\n", cardHolder);

        // Display last 4 digits of the card only
        System.out.printf("Card: ****-****-****-%s\n",
                cardNumber.substring(cardNumber.length() - 4));

        // Simulate processing time
        simulateProcessing();

        // Simulate a 5% chance of payment decline
        if (Math.random() < 0.05) {
            throw new PaymentException("Payment declined by bank");
        }

        System.out.println("✓ Payment successful!");
        return true;
    }

    /*
     * Returns the name of the payment method.
     *
     * @return "Credit Card"
     */
    @Override
    public String getPaymentMethodName() {
        return "Credit Card";
    }

    // ============================================================
    // PRIVATE HELPER METHODS
    // ============================================================

    /*
     * Simulates payment processing delay with dots
     * to mimic real transaction time.
     */
    private void simulateProcessing() {
        System.out.print("Processing");
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(500);
                System.out.print(".");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println();
    }
}
