
package demoppp;

// ============================================================
// PAYMENT PROCESSOR INTERFACE
// ============================================================

public interface PaymentProcessor {

    /*
     * Processes a payment for the given booking ID and amount.
     *
     * @param bookingId  Unique booking identifier
     * @param amount     Total amount to be paid
     * @return           true if payment successful, false otherwise
     * @throws PaymentException if payment fails or invalid
     */
    boolean processPayment(String bookingId, double amount) throws PaymentException;

    /*
     * Returns the name of the payment method.
     * Examples: "Credit Card", "Bkash", "PayPal"
     *
     * @return Payment method name as String
     */
    String getPaymentMethodName();
}
