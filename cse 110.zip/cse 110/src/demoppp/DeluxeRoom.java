
package demoppp;

// ============================================================
// DELUXE ROOM CLASS
// ============================================================
class DeluxeRoom extends Room {

    // Indicates whether the room has a balcony
    private boolean hasBalcony;

    // Indicates whether the room has a mini bar
    private boolean hasMiniBar;

    // Indicates whether the room has a jacuzzi
    private boolean hasJacuzzi;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    /*
     * Creates a DeluxeRoom object with premium facilities.
     *
     * @param roomNumber     Unique room identifier
     * @param pricePerNight  Cost per night
     * @param capacity       Maximum number of guests
     * @param hasBalcony     Balcony availability
     * @param hasMiniBar     Mini bar availability
     * @param hasJacuzzi     Jacuzzi availability
     */
    public DeluxeRoom(String roomNumber, double pricePerNight, int capacity,
            boolean hasBalcony, boolean hasMiniBar, boolean hasJacuzzi) {

        // Call parent Room constructor
        super(roomNumber, pricePerNight, capacity);

        // Initialize deluxe room facilities
        this.hasBalcony = hasBalcony;
        this.hasMiniBar = hasMiniBar;
        this.hasJacuzzi = hasJacuzzi;
    }

    // ============================================================
    // OVERRIDDEN METHODS
    // ============================================================

    /*
     * Returns the type of room.
     * Overridden from the Room class.
     */
    @Override
    public String getRoomType() {
        return "Deluxe";
    }

    /*
     * Returns a formatted string containing
     * all deluxe room details and facilities.
     */
    @Override
    public String getRoomDetails() {
        return String.format("Deluxe Room %s\n"
                + "• Capacity: %d guests\n"
                + "• Price: $%.2f per night\n"
                + "• Balcony: %s\n"
                + "• Mini Bar: %s\n"
                + "• Jacuzzi: %s\n"
                + "• Status: %s",
                getRoomNumber(), getCapacity(), getPricePerNight(),
                hasBalcony ? "Yes" : "No",
                hasMiniBar ? "Stocked" : "Not Available",
                hasJacuzzi ? "Available" : "Not Available",
                isAvailable() ? "Available" : "Booked");
    }
}
