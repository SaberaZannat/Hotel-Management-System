
package demoppp;

/**
 * Exception thrown when a room is not found in the hotel system.
 */
class RoomNotFoundException extends Exception {

    /**
     * Constructor that accepts a custom error message.
     *
     * @param message The error message describing why the exception was thrown.
     */
    public RoomNotFoundException(String message) {
        super(message);
    }
}
