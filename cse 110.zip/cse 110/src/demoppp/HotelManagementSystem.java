
package demoppp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class HotelManagementSystem {

    // List of all rooms in the hotel
    private List<Room> rooms;

    // List of registered customers
    private List<Customer> customers;

    // List of all bookings
    private List<Booking> bookings;

    // Scanner object for reading console input
    private Scanner scanner;

    /**
     * Constructor initializes the hotel management system. It sets up rooms,
     * customers, and prepares the scanner for input.
     */
    public HotelManagementSystem() {
        rooms = new ArrayList<>();
        customers = new ArrayList<>();
        bookings = new ArrayList<>();
        scanner = new Scanner(System.in);
        initializeRooms();
        initializeCustomers();
    }

    /**
     * Initializes the rooms in the hotel with predefined Standard, Deluxe, and
     * Suite rooms.
     */
    private void initializeRooms() {
        // Add standard rooms
        rooms.add(new StandardRoom("101", 100.0, 2, true, true));
        rooms.add(new StandardRoom("102", 100.0, 2, true, true));
        rooms.add(new StandardRoom("103", 90.0, 2, false, true));
        rooms.add(new StandardRoom("104", 90.0, 2, true, false));

        // Add deluxe rooms
        rooms.add(new DeluxeRoom("201", 200.0, 3, true, true, true));
        rooms.add(new DeluxeRoom("202", 200.0, 3, true, true, true));
        rooms.add(new DeluxeRoom("203", 180.0, 2, true, true, false));

        // Add suite rooms
        rooms.add(new SuiteRoom("301", 350.0, 4, 2, true));
        rooms.add(new SuiteRoom("302", 400.0, 6, 3, true));
    }

    /**
     * Initializes a few default customers in the system.
     */
    private void initializeCustomers() {
        customers.add(new Customer("C001", "John Smith", "john@email.com", "123-456-7890"));
        customers.add(new Customer("C002", "Emma Wilson", "emma@email.com", "987-654-3210"));
        customers.add(new Customer("C003", "David Brown", "david@email.com", "555-123-4567"));
    }

    // ============================================================
    // ROOM MANAGEMENT METHODS
    // ============================================================

    /**
     * Returns a list of rooms that are currently available for booking.
     *
     * @return List of available Room objects
     */
    private List<Room> getAvailableRooms() {
        List<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    /**
     * Displays a formatted list of all rooms in the hotel.
     */
    private void displayAllRooms() {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                     ALL ROOMS                          │");
        System.out.println("├─────────────────────────────────────────────────────────┤");

        if (rooms.isEmpty()) {
            System.out.println("│ No rooms in the system                                │");
        } else {
            for (int i = 0; i < rooms.size(); i++) {
                System.out.printf("│ %d. %-55s │\n", i + 1, rooms.get(i));
            }
        }
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Displays a formatted list of rooms that are currently available for
     * booking.
     */
    private void displayAvailableRooms() {
        List<Room> availableRooms = getAvailableRooms();
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                  AVAILABLE ROOMS                       │");
        System.out.println("├─────────────────────────────────────────────────────────┤");

        if (availableRooms.isEmpty()) {
            System.out.println("│ No rooms available at the moment                       │");
        } else {
            for (int i = 0; i < availableRooms.size(); i++) {
                System.out.printf("│ %d. %-55s │\n", i + 1, availableRooms.get(i));
            }
        }
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Finds a room by its room number.
     *
     * @param roomNumber Room number to search
     * @return Room object if found
     * @throws RoomNotFoundException if no room with given number exists
     */
    private Room findRoomByNumber(String roomNumber) throws RoomNotFoundException {
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        throw new RoomNotFoundException("Room " + roomNumber + " not found");
    }

    /**
     * Displays detailed information about a room by its number.
     *
     * @param roomNumber Room number
     * @throws RoomNotFoundException if room is not found
     */
    private void displayRoomDetails(String roomNumber) throws RoomNotFoundException {
        Room room = findRoomByNumber(roomNumber);
        System.out.println("\n" + room.getRoomDetails());
    }

    // ============================================================
    // CUSTOMER MANAGEMENT METHODS
    // ============================================================

    /**
     * Displays all registered customers in the system.
     */
    private void displayAllCustomers() {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                    ALL CUSTOMERS                       │");
        System.out.println("├─────────────────────────────────────────────────────────┤");

        if (customers.isEmpty()) {
            System.out.println("│ No customers registered                               │");
        } else {
            for (Customer customer : customers) {
                System.out.println("│ " + customer + " │");
            }
        }
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Finds a customer by their unique ID.
     *
     * @param customerId Customer ID to search
     * @return Customer object if found, otherwise null
     */
    private Customer findCustomerById(String customerId) {
        for (Customer customer : customers) {
            if (customer.getId().equals(customerId)) {
                return customer;
            }
        }
        return null;
    }

    /**
     * Registers a new customer by taking input from the console.
     *
     * @return Newly created Customer object
     * @throws InvalidInputException If input values are invalid
     */
    private Customer registerNewCustomer() throws InvalidInputException {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│               NEW CUSTOMER REGISTRATION                │");
        System.out.println("└─────────────────────────────────────────────────────────┘");

        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            throw new InvalidInputException("Name cannot be empty");
        }

        System.out.print("Enter email: ");
        String email = scanner.nextLine().trim();
        if (!email.contains("@")) {
            throw new InvalidInputException("Invalid email format");
        }

        System.out.print("Enter phone: ");
        String phone = scanner.nextLine().trim();
        if (phone.length() < 10) {
            throw new InvalidInputException("Phone number must be at least 10 digits");
        }

        String customerId = "C" + String.format("%03d", customers.size() + 1);
        Customer customer = new Customer(customerId, name, email, phone);
        customers.add(customer);

        System.out.println("\n✓ Registration successful!");
        System.out.println("Customer ID: " + customerId);

        return customer;
    }

    /**
     * Gets a customer either by existing ID or by registering a new one.
     *
     * @return Customer object
     * @throws InvalidInputException if user input is invalid
     */
    private Customer getCustomer() throws InvalidInputException {
        System.out.println("\nDo you have a customer ID? (yes/no)");
        System.out.print("Your choice: ");
        String choice = scanner.nextLine().trim().toLowerCase();

        if (choice.equals("yes") || choice.equals("y")) {
            System.out.print("Enter your customer ID: ");
            String customerId = scanner.nextLine().trim().toUpperCase();

            Customer customer = findCustomerById(customerId);
            if (customer != null) {
                System.out.println("\nWelcome back, " + customer.getName() + "!");
                return customer;
            } else {
                System.out.println("\nCustomer ID not found. Please register as a new customer.");
                return registerNewCustomer();
            }
        } else {
            return registerNewCustomer();
        }
    }
    
    // ============================================================
    // BOOKING MANAGEMENT METHODS (PART 1)
    // ============================================================

    /**
     * Reads a date input from the console and parses it into LocalDate.
     *
     * @param prompt Prompt message
     * @return LocalDate object
     * @throws InvalidInputException if input date format is invalid
     */
    private LocalDate getDateInput(String prompt) throws InvalidInputException {
        System.out.print(prompt + " (YYYY-MM-DD): ");
        String dateString = scanner.nextLine().trim();

        try {
            return LocalDate.parse(dateString);
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("Invalid date format. Please use YYYY-MM-DD");
        }
    }

    /**
     * Prompts the user to select an available room from the list.
     *
     * @return Selected Room object
     * @throws RoomNotFoundException if the selected room number is invalid
     * @throws RoomNotAvailableException if no rooms are available
     */
    private Room selectAvailableRoom() throws RoomNotFoundException, RoomNotAvailableException {
        List<Room> availableRooms = getAvailableRooms();

        if (availableRooms.isEmpty()) {
            throw new RoomNotAvailableException("No rooms available for booking");
        }

        System.out.println("\nAvailable Rooms:");
        for (int i = 0; i < availableRooms.size(); i++) {
            System.out.printf("%d. %s\n", i + 1, availableRooms.get(i));
        }

        System.out.print("\nSelect room by number: ");
        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine().trim());
            if (choice < 1 || choice > availableRooms.size()) {
                throw new RoomNotFoundException("Invalid room selection");
            }
            return availableRooms.get(choice - 1);
        } catch (NumberFormatException e) {
            throw new RoomNotFoundException("Please enter a valid number");
        }
    }

    /**
     * Reads a yes/no boolean input from the user.
     *
     * @param prompt Prompt message
     * @return true if user enters yes, false if user enters no
     */
    private boolean getBooleanInput(String prompt) {
        while (true) {
            System.out.print(prompt + " (yes/no): ");
            String input = scanner.nextLine().trim().toLowerCase();

            if (input.equals("yes") || input.equals("y")) {
                return true;
            } else if (input.equals("no") || input.equals("n")) {
                return false;
            }
            System.out.println("Please enter 'yes' or 'no'");
        }
    }

    /**
     * Reads an integer input from the user within a specified range.
     *
     * @param prompt Prompt message
     * @param min Minimum valid value
     * @param max Maximum valid value
     * @return Entered integer
     * @throws InvalidInputException if input is invalid or out of range
     */
    private int getIntegerInput(String prompt, int min, int max) throws InvalidInputException {
        System.out.print(prompt + " (" + min + "-" + max + "): ");
        try {
            int value = Integer.parseInt(scanner.nextLine().trim());
            if (value < min || value > max) {
                throw new InvalidInputException("Value must be between " + min + " and " + max);
            }
            return value;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid number");
        }
    }

    /**
     * Prompts user to select a payment method and returns a corresponding
     * PaymentProcessor object.
     *
     * @return PaymentProcessor object
     * @throws InvalidInputException if the selected payment method is invalid
     */
    private PaymentProcessor selectPaymentMethod() throws InvalidInputException {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                 PAYMENT METHODS                        │");
        System.out.println("├─────────────────────────────────────────────────────────┤");
        System.out.println("│ 1. Credit Card                                         │");
        System.out.println("│ 2. Cash                                                │");
        System.out.println("│ 3. PayPal                                              │");
        System.out.println("└─────────────────────────────────────────────────────────┘");

        System.out.print("Select payment method (1-3): ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                return getCreditCardDetails();
            case "2":
                return new CashPayment();
            case "3":
                return (PaymentProcessor) new OnlinePayment("PayPal");
            default:
                throw new InvalidInputException("Invalid payment method");
        }
    }

    /**
     * Prompts the user to enter credit card details.
     *
     * @return CreditCardPayment object
     * @throws InvalidInputException if input is invalid
     */
    private CreditCardPayment getCreditCardDetails() throws InvalidInputException {
        System.out.print("Card Holder Name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            throw new InvalidInputException("Card holder name cannot be empty");
        }

        System.out.print("Card Number (16 digits): ");
        String cardNumber = scanner.nextLine().trim().replaceAll("\\s", "");
        if (cardNumber.length() != 16 || !cardNumber.matches("\\d+")) {
            throw new InvalidInputException("Invalid card number");
        }

        return new CreditCardPayment(cardNumber, name);
    }

    /**
     * Creates a new booking by performing the following steps: 1. Get or
     * register a customer 2. Display available rooms and select one 3. Get
     * check-in and check-out dates 4. Ask for additional services like
     * breakfast and extra beds 5. Create the booking object and mark room as
     * unavailable 6. Optionally process payment
     */
    private void createNewBooking() {
        try {
            System.out.println("\n┌─────────────────────────────────────────────────────────┐");
            System.out.println("│                   NEW BOOKING                          │");
            System.out.println("└─────────────────────────────────────────────────────────┘");

            // Step 1: Get customer
            Customer customer = getCustomer();

            // Step 2: Show available rooms and select one
            displayAvailableRooms();
            Room selectedRoom = selectAvailableRoom();

            // Step 3: Get dates
            LocalDate checkInDate = getDateInput("Check-in date");
            LocalDate checkOutDate = getDateInput("Check-out date");

            if (checkOutDate.isBefore(checkInDate) || checkOutDate.isEqual(checkInDate)) {
                throw new InvalidInputException("Check-out date must be after check-in date");
            }

            // Step 4: Additional services
            boolean includeBreakfast = getBooleanInput("Include breakfast? ($20 per night)");
            int extraBeds = 0;

            if (getBooleanInput("Need extra beds? ($30 per bed per night)")) {
                extraBeds = getIntegerInput("Number of extra beds", 0, selectedRoom.getCapacity() * 2);
            }

            // Step 5: Create booking
            Booking booking = new Booking(customer, selectedRoom, checkInDate,
                    checkOutDate, includeBreakfast, extraBeds);

            selectedRoom.setAvailable(false);
            bookings.add(booking);

            System.out.println("\n✓ Booking created successfully!");
            System.out.println("Booking ID: " + booking.getBookingId());
            System.out.println("\n" + booking.getBookingSummary());

            // Step 6: Process payment
            System.out.println("\nDo you want to pay now? (yes/no)");
            if (getBooleanInput("Proceed to payment")) {
                PaymentProcessor paymentMethod = selectPaymentMethod();
                booking.processPayment(paymentMethod);
                System.out.println("\n" + booking.getBookingSummary());
            }

        } catch (Exception e) {
            System.out.println("\n✗ Error: " + e.getMessage());
        }
    }

    /**
     * Displays all bookings in the system with a formatted table.
     */
    private void displayAllBookings() {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                    ALL BOOKINGS                        │");
        System.out.println("├─────────────────────────────────────────────────────────┤");

        if (bookings.isEmpty()) {
            System.out.println("│ No bookings found                                    │");
        } else {
            for (Booking booking : bookings) {
                System.out.println("│ " + booking + " │");
            }
        }
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Finds a booking by its unique booking ID and displays its summary.
     */
    private void findBookingById() {
        System.out.print("\nEnter booking ID: ");
        String bookingId = scanner.nextLine().trim().toUpperCase();

        for (Booking booking : bookings) {
            if (booking.getBookingId().equals(bookingId)) {
                System.out.println("\n" + booking.getBookingSummary());
                return;
            }
        }
        System.out.println("\n✗ Booking not found: " + bookingId);
    }

    /**
     * Cancels a booking by its ID, updates room availability, and confirms
     * cancellation from the user if the booking is already paid.
     */
    private void cancelBooking() {
        try {
            System.out.print("\nEnter booking ID to cancel: ");
            String bookingId = scanner.nextLine().trim().toUpperCase();

            Booking bookingToCancel = null;
            for (Booking booking : bookings) {
                if (booking.getBookingId().equals(bookingId)) {
                    bookingToCancel = booking;
                    break;
                }
            }

            if (bookingToCancel == null) {
                throw new BookingException("Booking not found: " + bookingId);
            }

            if (bookingToCancel.isPaid()) {
                System.out.println("This booking has been paid. Are you sure you want to cancel?");
                if (!getBooleanInput("Confirm cancellation")) {
                    System.out.println("Cancellation aborted");
                    return;
                }
            }

            // Make room available again
            bookingToCancel.getRoom().setAvailable(true);
            bookings.remove(bookingToCancel);

            System.out.println("\n✓ Booking " + bookingId + " cancelled successfully");

        } catch (Exception e) {
            System.out.println("\n✗ Error: " + e.getMessage());
        }
    }
    /**
     * Performs guest check-in by booking ID, ensuring payment has been
     * completed.
     */
    private void checkInGuest() {
        try {
            System.out.print("\nEnter booking ID for check-in: ");
            String bookingId = scanner.nextLine().trim().toUpperCase();

            for (Booking booking : bookings) {
                if (booking.getBookingId().equals(bookingId)) {
                    if (!booking.isPaid()) {
                        System.out.println("Cannot check in. Payment pending.");
                        return;
                    }

                    System.out.println("\n✓ Check-in successful for booking: " + bookingId);
                    System.out.println("Welcome to our hotel, " + booking.getCustomer().getName() + "!");
                    return;
                }
            }
            throw new BookingException("Booking not found: " + bookingId);

        } catch (Exception e) {
            System.out.println("\n✗ Error: " + e.getMessage());
        }
    }

    /**
     * Performs guest check-out by booking ID and makes the room available
     * again.
     */
    private void checkOutGuest() {
        try {
            System.out.print("\nEnter booking ID for check-out: ");
            String bookingId = scanner.nextLine().trim().toUpperCase();

            for (Booking booking : bookings) {
                if (booking.getBookingId().equals(bookingId)) {
                    booking.getRoom().setAvailable(true);
                    System.out.println("\n✓ Check-out successful for booking: " + bookingId);
                    System.out.println("Thank you for staying with us, " + booking.getCustomer().getName() + "!");
                    return;
                }
            }
            throw new BookingException("Booking not found: " + bookingId);

        } catch (Exception e) {
            System.out.println("\n✗ Error: " + e.getMessage());
        }
    }

    /**
     * Displays a summary report of all bookings including total bookings,
     * confirmed bookings, pending bookings, and total revenue collected.
     */
    private void displayBookingReport() {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                   BOOKING REPORT                       │");
        System.out.println("├─────────────────────────────────────────────────────────┤");
        System.out.printf("│ Total Bookings: %-41d │\n", bookings.size());

        int confirmedBookings = 0;
        double totalRevenue = 0;

        for (Booking booking : bookings) {
            if (booking.isPaid()) {
                confirmedBookings++;
                totalRevenue += booking.getTotalPrice();
            }
        }

        System.out.printf("│ Confirmed Bookings: %-36d │\n", confirmedBookings);
        System.out.printf("│ Pending Bookings: %-38d │\n", bookings.size() - confirmedBookings);
        System.out.printf("│ Total Revenue: $%-40.2f │\n", totalRevenue);
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Displays the main menu with options for rooms, customers, bookings,
     * check-in/out, and reports.
     */
    private void displayMainMenu() {
        System.out.println("\n┌─────────────────────────────────────────────────────────┐");
        System.out.println("│        HOTEL MANAGEMENT SYSTEM - MAIN MENU            │");
        System.out.println("├─────────────────────────────────────────────────────────┤");
        System.out.println("│ 1. View All Rooms                                      │");
        System.out.println("│ 2. View Available Rooms                                │");
        System.out.println("│ 3. View Room Details                                   │");
        System.out.println("│ 4. View All Customers                                  │");
        System.out.println("│ 5. Make a New Booking                                  │");
        System.out.println("│ 6. View All Bookings                                   │");
        System.out.println("│ 7. Find Booking by ID                                  │");
        System.out.println("│ 8. Cancel Booking                                      │");
        System.out.println("│ 9. Check-in Guest                                      │");
        System.out.println("│10. Check-out Guest                                     │");
        System.out.println("│11. Booking Report                                      │");
        System.out.println("│12. Exit                                                │");
        System.out.println("└─────────────────────────────────────────────────────────┘");
    }

    /**
     * Starts the hotel management system by displaying the welcome message and
     * continuously handling user input until exit is selected.
     */
    public void start() {
        System.out.println("\n╔══════════════════════════════════════════════════════════╗");
        System.out.println("║      WELCOME TO HOTEL MANAGEMENT SYSTEM                ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝");

        boolean running = true;

        while (running) {
            displayMainMenu();
            System.out.print("\nEnter your choice (1-12): ");
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        displayAllRooms();
                        break;
                    case "2":
                        displayAvailableRooms();
                        break;
                    case "3":
                        System.out.print("Enter room number: ");
                        String roomNumber = scanner.nextLine().trim();
                        displayRoomDetails(roomNumber);
                        break;
                    case "4":
                        displayAllCustomers();
                        break;
                    case "5":
                        createNewBooking();
                        break;
                    case "6":
                        displayAllBookings();
                        break;
                    case "7":
                        findBookingById();
                        break;
                    case "8":
                        cancelBooking();
                        break;
                    case "9":
                        checkInGuest();
                        break;
                    case "10":
                        checkOutGuest();
                        break;
                    case "11":
                        displayBookingReport();
                        break;
                    case "12":
                        running = false;
                        System.out.println("\nThank you for using Hotel Management System. Goodbye!");
                        break;
                    default:
                        System.out.println("\n✗ Invalid choice. Please enter 1-12.");
                }
            } catch (Exception e) {
                System.out.println("\n✗ Error: " + e.getMessage());
            }

            if (running && !choice.equals("12")) {
                System.out.print("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }

        scanner.close();
    }
}
