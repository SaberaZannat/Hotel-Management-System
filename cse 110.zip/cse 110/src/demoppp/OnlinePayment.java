
package demoppp;

// ============================================================
// ONLINE PAYMENT CLASS
// ============================================================

class OnlinePayment implements PaymentProcessor {

    // Name of the online payment provider (e.g., PayPal, Bkash)
    private String provider;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    /*
     * Creates an OnlinePayment object for a given provider.
     *
     * @param provider  Name of the online payment provider
     */
    public OnlinePayment(String provider) {
        this.provider = provider;
    }

    // ============================================================
    // INTERFACE METHODS
    // ============================================================

    /*
     * Processes an online payment for the given booking ID and amount.
     * Simulates connecting to a payment gateway and a small chance of failure.
     *
     * @param bookingId  Booking ID for payment
     * @param amount     Payment amount
     * @return           true if payment successful
     * @throws PaymentException if online payment fails
     */
    @Override
    public boolean processPayment(String bookingId, double amount) throws PaymentException {
        System.out.printf("\nProcessing %s Payment...\n", provider);
        System.out.printf("Booking: %s\n", bookingId);
        System.out.printf("Amount: $%.2f\n", amount);

        // Simulate gateway processing delay
        simulateProcessing();

        // Random failure chance (3%)
        if (Math.random() < 0.03) {
            throw new PaymentException("Online payment failed. Please try again");
        }

        System.out.println("✓ Online payment successful!");
        return true;
    }

    /*
     * Returns the payment method name, including provider.
     *
     * @return provider + " Payment"
     */
    @Override
    public String getPaymentMethodName() {
        return provider + " Payment";
    }

    // ============================================================
    // PRIVATE HELPER METHODS
    // ============================================================

    /*
     * Simulates connecting to the online payment gateway
     * by printing dots with delay.
     */
    private void simulateProcessing() {
        System.out.print("Connecting to payment gateway");
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(500);
                System.out.print(".");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println();
    }
}
