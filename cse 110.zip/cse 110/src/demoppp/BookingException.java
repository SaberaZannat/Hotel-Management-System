
package demoppp;

/**
 * Exception thrown when a booking-related operation fails.
 * For example, if a booking ID is not found or a cancellation is invalid.
 */
class BookingException extends Exception {

    /**
     * Constructor that accepts a custom error message.
     *
     * @param message The error message describing why the exception was thrown.
     */
    public BookingException(String message) {
        super(message); // Pass the message to the base Exception class
    }
}
