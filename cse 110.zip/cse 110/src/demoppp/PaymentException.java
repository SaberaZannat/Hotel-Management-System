
package demoppp;

/**
 * Exception thrown when a payment-related operation fails.
 * For example, if a credit card is declined or an online payment fails.
 */
class PaymentException extends Exception {

    /**
     * Constructor that accepts a custom error message.
     *
     * @param message The error message describing why the exception was thrown.
     */
    public PaymentException(String message) {
        super(message); // Pass the message to the base Exception class
    }
}
