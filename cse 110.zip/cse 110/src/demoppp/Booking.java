
package demoppp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

// ============================================================
// BOOKING CLASS
// ============================================================
class Booking {

    // Static counter to generate unique booking IDs
    private static int bookingCounter = 1000;

    // ------------------------
    // Instance Variables
    // ------------------------
    // Unique booking ID
    private String bookingId;

    // Customer who made the booking
    private Customer customer;

    // Room that is booked
    private Room room;

    // Check-in date
    private LocalDate checkInDate;

    // Check-out date
    private LocalDate checkOutDate;

    // Total nights stayed
    private int numberOfNights;

    // Total booking cost
    private double totalPrice;

    // Payment status
    private boolean isPaid;

    // Payment method used
    private PaymentProcessor paymentMethod;

    // Breakfast option
    private boolean isBreakfastIncluded;

    // Number of extra beds
    private int extraBeds;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    /*
     * Creates a new booking object with all required details.
     * It also validates dates and calculates price automatically.
     */
    public Booking(Customer customer, Room room, LocalDate checkInDate,
            LocalDate checkOutDate, boolean isBreakfastIncluded,
            int extraBeds) throws BookingException {

        this.bookingId = generateBookingId();
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.isBreakfastIncluded = isBreakfastIncluded;
        this.extraBeds = extraBeds;
        this.isPaid = false;

        // Validate dates and calculate booking details
        validateDates();
        calculateNumberOfNights();
        calculateTotalPrice();
    }

    // ============================================================
    // PRIVATE HELPER METHODS
    // ============================================================
    // Generates a unique booking ID
    private String generateBookingId() {
        return "BK" + bookingCounter++;
    }

    /*
     * Validates check-in and check-out dates.
     * Throws exception if:
     * - Check-out is before or equal to check-in
     * - Check-in date is in the past
     */
    private void validateDates() throws BookingException {
        if (checkOutDate.isBefore(checkInDate) || checkOutDate.isEqual(checkInDate)) {
            throw new BookingException("Check-out date must be after check-in date");
        }

        if (checkInDate.isBefore(LocalDate.now())) {
            throw new BookingException("Check-in date cannot be in the past");
        }
    }

    // Calculates total number of nights stayed
    private void calculateNumberOfNights() {
        this.numberOfNights
                = (int) ChronoUnit.DAYS.between(checkInDate, checkOutDate);
    }

    /*
     * Calculates total booking price:
     * - Base room price
     * - Breakfast cost (if included)
     * - Extra bed cost
     */
    private void calculateTotalPrice() {
        double basePrice = room.calculateTotalPrice(numberOfNights);
        double breakfastCost = isBreakfastIncluded ? 20.0 * numberOfNights : 0;
        double extraBedsCost = extraBeds * 30.0 * numberOfNights;

        this.totalPrice = basePrice + breakfastCost + extraBedsCost;
    }

    // ============================================================
    // GETTER METHODS
    // ============================================================
    public String getBookingId() {
        return bookingId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Room getRoom() {
        return room;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public int getNumberOfNights() {
        return numberOfNights;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public PaymentProcessor getPaymentMethod() {
        return paymentMethod;
    }

    public boolean isBreakfastIncluded() {
        return isBreakfastIncluded;
    }

    public int getExtraBeds() {
        return extraBeds;
    }

    // ============================================================
    // PAYMENT PROCESSING
    // ============================================================

    /*
     * Processes payment using a PaymentProcessor.
     * If payment is successful, booking is marked as paid.
     */
    public void processPayment(PaymentProcessor paymentProcessor)
            throws PaymentException {

        boolean success
                = paymentProcessor.processPayment(bookingId, totalPrice);

        if (success) {
            this.paymentMethod = paymentProcessor;
            this.isPaid = true;
        }
    }

    // ============================================================
    // BOOKING SUMMARY
    // ============================================================

    /*
     * Returns a formatted booking confirmation summary.
     * Used for printing booking details.
     */
    public String getBookingSummary() {
        DateTimeFormatter formatter
                = DateTimeFormatter.ofPattern("dd MMM yyyy");

        return String.format(
                "┌──────────────────────────────────────────┐\n"
                + "│           BOOKING CONFIRMATION          │\n"
                + "├──────────────────────────────────────────┤\n"
                + "│ Booking ID:    %-25s │\n"
                + "│ Customer:      %-25s │\n"
                + "│ Room:          %-25s │\n"
                + "│ Check-in:      %-25s │\n"
                + "│ Check-out:     %-25s │\n"
                + "│ Nights:        %-25d │\n"
                + "│ Breakfast:     %-25s │\n"
                + "│ Extra Beds:    %-25d │\n"
                + "│ Total Price:   $%-24.2f │\n"
                + "│ Payment:       %-25s │\n"
                + "│ Status:        %-25s │\n"
                + "└──────────────────────────────────────────┘",
                bookingId,
                customer.getName(),
                room.getRoomNumber() + " (" + room.getRoomType() + ")",
                checkInDate.format(formatter),
                checkOutDate.format(formatter),
                numberOfNights,
                isBreakfastIncluded ? "Included" : "Not Included",
                extraBeds,
                totalPrice,
                paymentMethod != null ? paymentMethod.getPaymentMethodName() : "Pending",
                isPaid ? "CONFIRMED" : "PENDING PAYMENT");
    }
}
