
package demoppp;

/**
 * Exception thrown when a selected room is not available for booking.
 */
class RoomNotAvailableException extends Exception {

    /**
     * Constructor that accepts a custom error message.
     *
     * @param message The error message describing why the exception was thrown.
     */
    public RoomNotAvailableException(String message) {
        super(message);
    }
}
