
package demoppp;

/**
 * Exception thrown when the user provides invalid input.
 * Ensures that the system can handle incorrect or unexpected data gracefully.
 */
class InvalidInputException extends Exception {

    /**
     * Constructor that accepts a custom error message.
     *
     * @param message The error message describing the invalid input.
     */
    public InvalidInputException(String message) {
        super(message); // Pass the message to the base Exception class
    }
}
