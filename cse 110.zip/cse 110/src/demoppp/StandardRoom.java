
package demoppp;

// ============================================================
// STANDARD ROOM CLASS
// ============================================================

class StandardRoom extends Room {

    // Indicates whether the room has WiFi facility
    private boolean hasWiFi;

    // Indicates whether the room has TV facility
    private boolean hasTV;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    /*
     * Creates a StandardRoom object with basic room details
     * and standard facilities.
     *
     * @param roomNumber       Unique room identifier
     * @param pricePerNight    Cost per night
     * @param capacity         Maximum number of guests
     * @param hasWiFi          WiFi availability
     * @param hasTV            TV availability
     */
    public StandardRoom(String roomNumber, double pricePerNight, int capacity,
            boolean hasWiFi, boolean hasTV) {

        // Call parent (Room) constructor
        super(roomNumber, pricePerNight, capacity);

        // Initialize standard room facilities
        this.hasWiFi = hasWiFi;
        this.hasTV = hasTV;
    }

    // ============================================================
    // OVERRIDDEN METHODS
    // ============================================================

    /*
     * Returns the type of room.
     * This method is overridden from the Room class.
     */
    @Override
    public String getRoomType() {
        return "Standard";
    }

    /*
     * Returns detailed information about the room,
     * including facilities and availability status.
     */
    @Override
    public String getRoomDetails() {
        return String.format("Standard Room %s\n"
                + "• Capacity: %d guests\n"
                + "• Price: $%.2f per night\n"
                + "• WiFi: %s\n"
                + "• TV: %s\n"
                + "• Status: %s",
                getRoomNumber(), getCapacity(), getPricePerNight(),
                hasWiFi ? "Available" : "Not Available",
                hasTV ? "Available" : "Not Available",
                isAvailable() ? "Available" : "Booked");
    }

    // ============================================================
    // GETTER & SETTER METHODS
    // ============================================================

    // Returns WiFi availability status
    public boolean hasWiFi() {
        return hasWiFi;
    }

    // Updates WiFi availability
    public void setHasWiFi(boolean hasWiFi) {
        this.hasWiFi = hasWiFi;
    }

    // Returns TV availability status
    public boolean hasTV() {
        return hasTV;
    }

    // Updates TV availability
    public void setHasTV(boolean hasTV) {
        this.hasTV = hasTV;
    }
}
