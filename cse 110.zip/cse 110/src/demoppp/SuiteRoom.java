
package demoppp;

// ============================================================
// SUITE ROOM CLASS
// ============================================================

class SuiteRoom extends Room {

    // Number of bedrooms in the suite
    private int numberOfBedrooms;

    // Indicates whether the suite has a kitchen
    private boolean hasKitchen;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    /*
     * Creates a SuiteRoom object with premium suite features.
     *
     * @param roomNumber        Unique room identifier
     * @param pricePerNight     Cost per night
     * @param capacity          Maximum number of guests
     * @param numberOfBedrooms  Total bedrooms in the suite
     * @param hasKitchen        Kitchen availability
     */
    public SuiteRoom(String roomNumber, double pricePerNight, int capacity,
            int numberOfBedrooms, boolean hasKitchen) {

        // Call parent Room constructor
        super(roomNumber, pricePerNight, capacity);

        // Initialize suite-specific facilities
        this.numberOfBedrooms = numberOfBedrooms;
        this.hasKitchen = hasKitchen;
    }

    // ============================================================
    // OVERRIDDEN METHODS
    // ============================================================

    /*
     * Returns the room type.
     * Overridden from the Room class.
     */
    @Override
    public String getRoomType() {
        return "Suite";
    }

    /*
     * Returns detailed information about the suite room,
     * including bedrooms, kitchen, and availability status.
     */
    @Override
    public String getRoomDetails() {
        return String.format("Suite Room %s\n"
                + "• Capacity: %d guests\n"
                + "• Price: $%.2f per night\n"
                + "• Bedrooms: %d\n"
                + "• Kitchen: %s\n"
                + "• Status: %s",
                getRoomNumber(), getCapacity(), getPricePerNight(),
                numberOfBedrooms,
                hasKitchen ? "Fully Equipped" : "Not Available",
                isAvailable() ? "Available" : "Booked");
    }

    // ============================================================
    // GETTER & SETTER METHODS
    // ============================================================

    // Returns number of bedrooms
    public int getNumberOfBedrooms() {
        return numberOfBedrooms;
    }

    // Updates number of bedrooms
    public void setNumberOfBedrooms(int numberOfBedrooms) {
        this.numberOfBedrooms = numberOfBedrooms;
    }

    // Returns kitchen availability
    public boolean hasKitchen() {
        return hasKitchen;
    }

    // Updates kitchen availability
    public void setHasKitchen(boolean hasKitchen) {
        this.hasKitchen = hasKitchen;
    }
}
