
package demoppp;

// ============================================================
// CASH PAYMENT CLASS
// ============================================================

class CashPayment implements PaymentProcessor {

    // ============================================================
    // INTERFACE METHODS
    // ============================================================

    /*
     * Processes a cash payment by providing instructions to the customer.
     * No real transaction is done; customer pays at reception.
     *
     * @param bookingId  Booking ID for which payment is made
     * @param amount     Amount to be paid
     * @return           true always since payment is accepted in person
     * @throws PaymentException Not applicable for cash
     */
    @Override
    public boolean processPayment(String bookingId, double amount) throws PaymentException {
        System.out.println("\nCash Payment Selected");
        System.out.printf("Booking: %s\n", bookingId);
        System.out.printf("Amount to pay at reception: $%.2f\n", amount);
        System.out.println("Please bring this booking ID to the hotel reception");
        return true;
    }

    /*
     * Returns the name of the payment method.
     *
     * @return "Cash"
     */
    @Override
    public String getPaymentMethodName() {
        return "Cash";
    }
}
