
package demoppp;

// ============================================================
// PERSON CLASS
// ============================================================

class Person {

    // Unique identifier of the person
    private String id;

    // Name of the person
    private String name;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    /*
     * Creates a Person object with ID and Name.
     *
     * @param id    Unique person identifier
     * @param name  Person's full name
     */
    public Person(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // ============================================================
    // GETTER & SETTER METHODS
    // ============================================================

    // Returns the person's ID
    public String getId() {
        return id;
    }

    // Updates the person's ID
    public void setId(String id) {
        this.id = id;
    }

    // Returns the person's name
    public String getName() {
        return name;
    }

    // Updates the person's name
    public void setName(String name) {
        this.name = name;
    }

    // ============================================================
    // TO STRING METHOD
    // ============================================================

    /*
     * Returns a formatted string containing
     * basic person information.
     */
    @Override
    public String toString() {
        return String.format("ID: %s, Name: %s", id, name);
    }
}
