package demoppp;

// ============================================================
// MAIN CLASS
// ============================================================
/**
 * Main class for running the Hotel Management System application.
 */
public class Main {

    /**
     * The main method serves as the entry point of the application. It creates
     * an instance of HotelManagementSystem and starts the system.
     *
     * @param args Command-line arguments (not used in this application)
     */
    public static void main(String[] args) {
        // Create a new instance of the hotel management system
        HotelManagementSystem hotelSystem = new HotelManagementSystem();

        // Start the interactive console-based system
        hotelSystem.start();
    }
}